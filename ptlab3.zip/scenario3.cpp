/*	NAME : MOHAMED ALIF FATHI BIN ABDUL LATIF
	NO MATRIC : A23CS0112	*/

#include <iostream>
#include <cstring>
#include <cctype>
#include <iomanip>
#include <fstream>
using namespace std;

float calculateKeywordPercentage (const char* input, char keyword [], int totalChar, int totalWord);

int main ()
{
	const int MAXSIZE = 1000;
	char keyword []= "data";
	
	int charCount = 0;
	int wordCount = 1;
	int keywordCount;
	char userInput [MAXSIZE];
	float keywordPercentage = 0;
	
	ifstream input;
	ofstream output;
	
	input.open("input2.txt");
	output.open("output2.txt");
	
	input.getline(userInput, MAXSIZE);
	output << "Input:" << endl;
	output << userInput;
	
	for (int i = 0; userInput[i] != '\0'; i++)
	{
		userInput[i] = tolower(userInput[i]);
			charCount++;
	}
	
	for (int j = 0; userInput[j] != '\0'; j++)
	{
		if (userInput [j] == ' ')
			wordCount++;
	}
	
	keywordPercentage = calculateKeywordPercentage (userInput, keyword, charCount, wordCount);
	
	
	output << showpoint << fixed << setprecision(2) << endl;
	output << "Percentage of lines containing the keyword \"" << keyword << "\": " << keywordPercentage << "%\n";
	
	input.close();
	output.close();
	
	cout << "Result written to 'output2.txt'";
	return 0;
}

float calculateKeywordPercentage (const char* input,char keyword [], int totalChar, int totalWord)
{
	int totalKeyword;
	
	for (int i = 0; i < totalChar; i++)
	{
		if (strstr((input + i), keyword) == (input + i))
			totalKeyword++;
	}
	
	float percentage = 0;
                
    percentage = static_cast<float>(totalKeyword) * 100.0 / totalWord;
    
    return percentage;
} 
