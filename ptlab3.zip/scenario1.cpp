/*	NAME : MOHAMED ALIF FATHI BIN ABDUL LATIF
	NO MATRIC : A23CS0112	*/

#include <iostream>
#include <cstring>
#include <cctype>
#include <iomanip>
using namespace std;

float calculateKeywordPercentage (const char input [], char keyword [], int totalChar, int totalWord);

int main ()
{
	const int MAXSIZE = 1000;
	char keyword []= "data";
	
	int charCount = 0;
	int wordCount = 1;
	int keywordCount;
	char userInput [MAXSIZE];
	float keywordPercentage = 0;
	
	cout << "Enter the input (up to 999 characters, end with empty line):" << endl;
	cin.getline(userInput, MAXSIZE);
	
	cout << endl << userInput;
	
	for (int i = 0; userInput[i] != '\0'; i++)
	{
		userInput[i] = tolower(userInput[i]);
			charCount++;
	}
	
	for (int j = 0; userInput[j] != '\0'; j++)
	{
		if (userInput [j] == ' ')
			wordCount++;
	}
	
	keywordPercentage = calculateKeywordPercentage (userInput, keyword, charCount, wordCount);
	
	
	cout << showpoint << fixed << setprecision(2) << endl;
	cout << "Percentage of lines containing the keyword \"" << keyword << "\": " << keywordPercentage << "%\n";
	
	return 0;
}

float calculateKeywordPercentage (const char input [],char keyword [], int totalChar, int totalWord)
{
	int totalKeyword;
	
	for (int i = 0; i < totalChar; i++)
	{
		if (strstr((input + i), keyword) == (input + i))
			totalKeyword++;
	}
	
	float percentage = 0;
                
    percentage = static_cast<float>(totalKeyword) * 100.0 / totalWord;
    
    return percentage;
} 
